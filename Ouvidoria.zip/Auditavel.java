import java.util.Date;

public interface Auditavel {
    String recuperarAutor();
    Date recuperarDataCriacao();
}